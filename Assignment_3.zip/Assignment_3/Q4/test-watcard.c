#include "io_test.h"
#include "watcard.h"

// DO NOT MODIFY THIS FILE

// this is an I/O test client for capacity

// look at the simple.in and simple.expect for
// a concrete example of how to use this test client

int main(void) {
  add_void_test("activate", activate, 2);
  add_int_test("get_id", get_id, 0);
  add_int_test("correct_pin", correct_pin, 1);
  add_void_test("deactivate", deactivate, 1);
  add_void_test("print_balance", print_balance, 0);
  add_int_test("get_balance", get_balance, 0);
  add_void_test("reload", reload, 1);
  add_void_test("purchase", purchase, 2);
  add_stop_test("quit");
  io_test();
}
