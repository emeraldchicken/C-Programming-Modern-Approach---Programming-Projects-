void activate(const int student_id, const int student_pin);
int get_id(void);
int correct_pin(const int student_pin);
void deactivate(const int student_pin);
void print_balance(void);
int get_balance(void);
void reload(const int amount);
void purchase(const int student_pin, const int amount);
