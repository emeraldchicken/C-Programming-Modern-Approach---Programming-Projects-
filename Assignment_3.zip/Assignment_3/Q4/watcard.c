#include <assert.h>
#include <stdio.h>
#include "watcard.h"

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:

/* useful printf strings:

  "INACTIVE WatCard!\n" (only used by print_balance)
  "INVALID WatCard ACTIVATION!\n"
  "INVALID WatCard DEACTIVATION!\n"
  "INVALID WatCard RELOAD!\n"
  "INVALID WatCard PURCHASE!\n"
  "[WatCard %d] Activated\n"
  "[WatCard %d] Deactivated. Refund: $%d.%02d\n"
  "[WatCard %d] Balance: $%d.%02d\n"
  "[WatCard %d] Reloaded: $%d.%02d\n"
  "[WatCard %d] Purchase: $%d.%02d\n"
  "[WatCard %d] Promo: $%d.%02d\n"

*/

static int balance = 0;
static bool activated = false;
static int id = 22222222;
static int pin = 1234;

/*Activate the WatCard with an 8­digit student ID and a 4­digit PIN and display a message. If the card is already activated, or the ID or PIN are invalid (the first digit of both the ID and PIN can not be zero), an invalid message is displayed. */
void activate(const int student_id, const int student_pin) {
  int first_id = student_id/100000000;
  int first_pin = student_pin/10000;
  
  if (first_id == 0 || first_pin == 0) {
    printf("INVALID WatCard ACTIVATION!\n");  
  }
  printf("[WatCard %d] Activated\n", student_id);
}

/*Return the ID for WatCard, or ­1 if the card is not activated */
int get_id(void) {
  if (activated) {
    return id;
  } else {
    return 1;
  }
}

/*Returns 1 if the PIN is correct and the card is activated, 0 otherwise.*/
int correct_pin(const int student_pin) {
  if (student_pin == pin) {
    return 1;  
  } 
  return 0;
}

/*Deactivate the WatCard and display the refund (remaining balance). If the card is inactive or the PIN is incorrect, an invalid message is displayed. */
void deactivate(const int student_pin) {
  if (activated == false || student_pin != pin) {
    printf("INVALID WatCard DEACTIVATION!\n");  
  }
  printf("[WatCard %d] Balance: $%d.%02d\n", balance);
}

/*Print the current balance of the watcard, or a message declaring that the WatCard is inactive. */
void print_balance(void) {
  if (activated == false) {
    printf("INACTIVE WatCard!\n");  
  }
  printf("[WatCard %d] Balance: $%d.%02d\n", balance);  
}

/*Returns the current balance, or ­1 if the card is not activated.  */
int get_balance(void) {
  if (activated == false) {
    return 1;
  }
  return balance;
}

/*Increases the balance of the watcard by amount and displays a message. If amount is not positive or the card is inactive, an invalid message is displayed. */
void reload(const int amount) {
  balance += amount;
  if (amount < 0 || activated == false) {
    printf("INACTIVE WatCard!\n");
  }
}

/*If the PIN provided is correct it decreases the balance of the watcard by amount and displays a message. An additional promotional message may be displayed (see below). If amount is not positive or greater than the balance or the card is inactive or the PIN is invalid, an invalid message is displayed.*/
void purchase(const int student_pin, const int amount) {
  
}

