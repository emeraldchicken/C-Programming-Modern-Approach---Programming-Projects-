#include <assert.h>
#include "usdist.h"
//#include "tolerance.h"

// a simple test client for usdist

int main(void) {
  const struct usdist three_ft = {3, 0};
  const struct usdist six_inch = {0, 6};
  const struct usdist three_ft_six = {3, 6};
  
  const struct room one_by_one = {{1, 0}, {1, 0}};
  
  assert(usdist_equal(six_inch, six_inch));
  assert(usdist_equal(six_inch, max_dist(six_inch, six_inch)));
  assert(usdist_equal(three_ft_six, add_dist(three_ft, six_inch)));
 // assert(within_tolerance(0.5, feet(six_inch), 0.01));
  assert(room_equal(one_by_one, one_by_one));
  assert(144 == sq_inch(one_by_one));
 // assert(within_tolerance(1, sq_ft(one_by_one), 0.01));
}