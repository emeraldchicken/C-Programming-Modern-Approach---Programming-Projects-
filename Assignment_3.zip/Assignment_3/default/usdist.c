#include "usdist.h"

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:

/////////////////////////////////////////
  
// DO NOT CHANGE THE FOLLOWING LINE
const int inches_per_foot = 12;

/////////////////////////////////////////

// usdist_equal(a, b) determines if a and b are the same distance
bool usdist_equal(struct usdist a, struct usdist b) {  
  return a.ft == b.ft && a.in == b.in;
}

// max_dist(a, b) returns the distance (a or b) that is larger
struct usdist max_dist(struct usdist a, struct usdist b) {
  if (a.ft > b.ft) {
    return a;
  } else if (b.ft > a.ft) {
    return b;  
  } else if (a.in > b.in) {
    return a;
  } else if (b.in > a.in) {
    return b;
  } else {
    return a;
  }
}

// add_dist(a, b) returns a valid distance corresponding to a + b
struct usdist add_dist(struct usdist a, struct usdist b) {
  if (a.in + b.in > 12) {
    const int in_ft = (a.in + b.in) / 12; 
    const int in_left = a.in + b.in - 12;
    struct usdist dist = {a.ft + b.ft + in_ft, in_left};
    return dist;
  } else {
    struct usdist dist = {a.ft + b.ft, a.in + b.in};
    return dist;
  }
}  

// feet(d) returns a represented as a real number of feet 
// example: 3ft 6in would be 3.5 feet if inches_per_feet is 12
double feet(struct usdist a) {
  return a.ft + (a.in /12);
}

// room_equal(a, b) determines if a and b have the same dimensions
//   HINT: they could have their height and width swapped
bool room_equal(struct room a, struct room b) {
  if (a.width.ft == b.width.ft && 
      a.height.ft == b.height.ft && 
      a.width.in == b.width.in &&
      a.height.in == b.height.in) {
    return true;
  } 
  return false;
}

// sq_inch(r) determines the area of the room in square inches
int sq_inch(struct room r) {
  int height = r.height.ft * 12 + r.height.in;
  int width = r.width.ft * 12 + r.width.in;
  return height * width;
}

// sq_ft(r) determines the area of the room in square feet
double sq_ft(struct room r) {
  int height = r.height.ft + r.height.in/12;
  int width = r.width.ft + r.width.in/12;
  return height * width;
}
