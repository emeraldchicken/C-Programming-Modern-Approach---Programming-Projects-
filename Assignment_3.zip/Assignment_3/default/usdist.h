#include <stdbool.h>

// A module for working with US Distances

// inches_per_foot must be > 1, and is currently 12
extern const int inches_per_foot;

// requires: ft >= 0
//           0 <= in < inches_per_foot
struct usdist {
  int ft;
  int in;
};

struct room {
  struct usdist width;
  struct usdist height;
};


// usdist_equal(a, b) determines if a and b are the same distance
bool usdist_equal(struct usdist a, struct usdist b);


// max_dist(a, b) returns the distance (a or b) that is larger
struct usdist max_dist(struct usdist a, struct usdist b);


// add_dist(a, b) returns a valid distance corresponding to a + b
struct usdist add_dist(struct usdist a, struct usdist b);


// feet(d) returns a represented as a real number of feet 
// example: 3ft 6in would be 3.5 feet if inches_per_feet is 12
double feet(struct usdist a);


// room_equal(a, b) determines if a and b have the same dimensions
//   HINT: they could have their height and width swapped
bool room_equal(struct room a, struct room b);


// sq_inch(r) determines the area of the room in square inches
int sq_inch(struct room r);


// sq_ft(r) determines the area of the room in square feet
double sq_ft(struct room r);
