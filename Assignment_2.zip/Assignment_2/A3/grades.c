#include "grades.h"

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:

int round_closest(const int a, const int b) {
  return 0;
}

int clicker_grade(const int total, const int correct, const int absent) {
  return 0;
}

int final_grade(const int part, const int assn, 
                const int midterm, const int final) {
  return 0;
}

int adjusted_final_grade(const int part, const int assn, 
                const int midterm, const int final) {
  return 0;
}
