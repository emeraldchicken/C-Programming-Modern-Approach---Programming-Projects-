// TODO: complete this interface

// requires: a >= 0, b > 0
int round_closest(const int a, const int b);


// requires: total is > 0 and divisible by 4
//           total >= correct + absent
int clicker_grade(const int total, const int correct, const int absent);


// requires: 0 <= all parameters <= 100
int final_grade(const int part, const int assn, 
                const int midterm, const int final);


// requires: 0 <= all parameters <= 100
int adjusted_final_grade(const int part, const int assn, 
                const int midterm, const int final);
