#include "io_test.h"
#include "grades.h"

// DO NOT MODIFY THIS FILE

// this is an I/O test client for grades
// see the assignment for more details

// look at the sample.in and sample.expect for
// a concrete example of how to use this test client

int main(void) {
  add_int_test("round_closest", round_closest, 2);
  add_int_test("clicker_grade", clicker_grade, 3);
  add_int_test("final_grade", final_grade, 4);
  add_int_test("adjusted_final_grade", adjusted_final_grade, 4);
  add_stop_test("quit");
  io_test();
}
