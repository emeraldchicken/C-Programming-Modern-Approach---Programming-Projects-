#include "translation.h"

// see translation.c for documentation

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:

// implementation functions below:

// TRANSLATE THE RACKET CODE INTO C AS DIRECTLY AS POSSIBLE

// this module provides functions translated from Racket

// polyeval(a, b, c, x) evaluates ax^2 + bx + c
int polyeval(const int a, const int b, const int c, const int x) {
  return a * x * x + b * x + c;
}

// selector(a, x, y) produces x if a is non-zero, and y otherwise
int selector(const int a, const int x, const int y) {
  if (a != 0) {
    return x;  
  } else {
    return y;  
  }
}

// max3(a, b, c) produces the max of a, b and c
int max3(const int a, const int b, const int c) {
  if (a > b && a > c) {
    return a;
  } else if (b > a && c > a) {
    return b;
  } else {
    return c;  
  }
}

// sumsqr1(n) produces the sum of 1^2, 2^2, .... n^2
int sumsqr1(const int n) {
  /*int sum = 0;
  for (int i = 1; i <= n; i++) {
    sum += i * i;
  }
  return sum;*/
  
  if (n == 0) {
    return 0;  
  } else {
    return (n * n) + sumsqr1(n - 1);  
  }
}

/*(define (sumsqr1 n)
  (cond [(zero? n) 0]
        [else (+ (* n n) (sumsqr1 (- n 1)))]))*/

int sumsqracc(int n sofar) {
  if (n == 0) {
    return sofar;  
  } else {
    sumsqracc((n - 1)  ((n * n) + sofar));
  }
}

// sumsqr2(n) produces the sum of 1^2, 2^2, .... n^2
int sumsqr2(const int n) {
  return sumsqr2acc(n 0);
}

/*;; (sumsqr2acc n sofar) produces the sum of 1^2, 2^2, .... n^2 + sofar
;; sumsqr1: Int Int -> Int

(define (sumsqr2acc n sofar)
  (cond [(zero? n) sofar]
        [else (sumsqr2acc (- n 1) (+ (* n n) sofar))]))


(define (sumsqr2 n)
  (sumsqr2acc n 0))


(define (sumsqr3 n)
  (/ (* n (+ n 1) (+ (* 2 n) 1)) 6))


(define (sameparity a b)
  (cond [(or (and (even? a) (even? b))
             (and (odd? a) (odd? b)))
         1]
        [else 0]))*/

// sumsqr3(n) produces the sum of 1^2, 2^2, .... n^2
//int sumsqr3(const int n);

// sameparity(a, b) produces 1 if a and b have the same parity (odd/even)
//   or 0 otherwise
// requires: a, b >= 0
int sameparity(const int a, const int b) {
  if (((a % 2 == 0) && (b % 2 == 0)) ||
      ((a % 2 != 0) && (b % 2 != ))) {
    return 1;
  } else {
    return 0;  
  }
}
