#include <stdio.h>

/**
  Write a program that reads in an arbitrary number of natural numbers and then prints the number of "upticks" in the sequence. An "uptick" is when a number is read in that was greater than the preceeding number. The sequence 3 1 1 4 1 5 9 has 3 upticks (1→4, 1→5, 5→9). Clearly, a sequence of less than two numbers would have zero upticks.
*/

int upstick(int count, int before) {
  int num = 0;
  while (scanf("%d", &num) == 1) {
    if (num > before) {
      count += 1;
      printf("up\n");
    }
    before = num;
  }
  return count;
}

int main(void) {
  int upstick_count = upstick(0,0) -1 ;
  printf("Count: %d\n", upstick_count);
}
