#include <stdio.h>
#include "readnat.h"

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:
  

/*Write a program that reads in an arbitrary number of natural numbers and then prints the largest number encountered (or 1 if there is no input). */

int max_num(int sofar) {
  const int r = readnat();
  
  if (r == -1) {
    return sofar;   
  } else if (r > sofar) {
    max_num(r);  
  } else {
    max_num(sofar);  
  }
}

int main(void) {
  const int max = max_num(0);
  printf("%d\n", max);
}

