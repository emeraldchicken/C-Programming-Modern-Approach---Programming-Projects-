/* Write a program that reads in an arbitrary number of natural numbers and then prints the number of odd numbers encountered. Clearly, if there is no input, then there would be zero odd numbers.*/

int odd_num(int sofar) {
  const int r = readnat();
  
  if (r == -1) {
    return sofar;  
  } else if (r % 2 != 0) {
    odd_num(sofar + 1);  
  } else {
    odd_num(sofar);  
  }
}

int main(void) {
  const int odd = odd_num(0);
  printf("%d\n", odd);
}