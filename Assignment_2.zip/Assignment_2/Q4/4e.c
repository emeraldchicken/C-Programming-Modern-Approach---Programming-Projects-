#include <stdio.h>

/*Write a program that first reads in a natural number (named "n") followed by an arbitrary number of natural numbers. The program prints the sum of every n­th number. For example, if the input is 3 10 20 30 40 50 60 70, then n is 3 so it would sum every 3rd number and print 90 (30 + 60). If n is 0 or there is no input, print ­1. If n is 1 then it should sum every number in the input (not including n).*/

int sum_nth() {
  int n = 0;
  int x = scanf("%d", &n);
  if (n == 0 || x == -1) {
    return 1;  
  }
  int nat = 0;
  int nth = 1;
  int sum = 0;
  
  while (scanf("%d", &nat) == 1) {
    if (nth % n == 0) {
      sum += nat;  
    }
  }
  return sum;
}

int main (void) {
  printf("SUM: %d\n", sum_nth());
}
