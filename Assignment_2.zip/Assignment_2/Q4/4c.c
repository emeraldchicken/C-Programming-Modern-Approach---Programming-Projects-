/*  Write a program that reads in an arbitrary number of natural numbers and then prints the difference between the largest and the smallest natural number encountered (or 1 if there is no input). */

int diff_fn(int max, int min) {
  const int r = readnat();
  
  if (r != -1) {
    return max - min;
  } else if (r > max) {
    diff_fn(r, min);  
  } else if (r < min) {
    diff_fn(max, r);
  } else {
    diff_fn(max, min);
  }
}

int main(void) {
  const int diff = diff_fn(1,0);
  printf("%d\n", diff);
}