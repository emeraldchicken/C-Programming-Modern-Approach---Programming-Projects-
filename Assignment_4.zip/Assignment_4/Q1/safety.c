#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include "safety.h"

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:

// see safety.h for interface documentation

// safe_add(a, b) returns a + b
// NOTE: if a+b causes overflow, an assertion fails
int safe_add(const int a, const int b) {
  if (INT_MAX - a >= b) {
    return a + b; 
  }
}
