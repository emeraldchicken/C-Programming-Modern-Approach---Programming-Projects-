// A module for safely performing addition

// safe_add(a, b) returns a + b
// NOTE: if a+b causes overflow, an assertion fails
int safe_add(const int a, const int b);

