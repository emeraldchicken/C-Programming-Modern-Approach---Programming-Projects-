#include <assert.h>
#include <limits.h>
#include "safety.h"

// a very simple test program

int main(void) {
  assert(safe_add(3, 4) == 7);
}