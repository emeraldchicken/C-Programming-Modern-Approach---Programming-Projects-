#include <stdio.h>
// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:
  
 
void checker(int width, int height, int size, char c1, char c2) {
  
}

/* void sequence(int len) simply prints the sequence from 1 to "len", separating each number by a comma (,) and ending with a period (.) and a newline.  For example, sequence(5) print*/ 
void sequence(int len) {
  for (int i = 1; i < len; ++i) {
    printf("%d, ", i);
  }
  printf("%d.\n", len);
}      

/*void fizz_buzz(int len, int fizz, int buzz) simulates a game of "fizz buzz" (see wikipedia entry but do not look at the programming example). "fizz" and "buzz" must be larger than 1 and cannot be equal. The function prints the sequence of number from 1 to "len", each on a new line. However, if the number is divisible by "fizz", it prints "fizz", and if it is divisible by buzz, it prints "buzz". If the number is divisible by both fizz and buzz, then it prints "fizz buzz".  For example, fizz_buzz(7, 2, 3) prints */
void fizz_buzz(int len, int fizz, int buzz) {
  for (int i = 1; i <= len; ++i) {
    printf("%d\n", i);
    if (i % fizz == 0) {
      printf("fizz\n");
    } else if (i % buzz == 0) {
      printf("buzz\n");
    } else if (i % fizz == 0 && i % buzz == 0) {
      printf("fizz buzz/n");
    }
  }
}

int main(void) {
  //fizz_buzz(100, 5, 3);  
  sequence(30);
}
