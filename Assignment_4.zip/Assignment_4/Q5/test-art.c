#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "black.h"
#include "gold.h"
#include "readchar.h"
#include "readnat.h"

// a testing framework for "the art of programming" - black & gold
// you should be able to follow most of this code now
// (but are not required to do so)

// get_nat() reads in a natural number from input (ignoring whitespace)
// effects: if unable to read in a number, prints message and exits
int get_nat(void) {
  const char len = readnat();
  if (len == -1) {
    printf("exit: invalid number\n");
    exit(1);
  }
  return len;
}

// get_dimension() reads in a character from input (ignoring whitespace)
// effects: if unable to read in a char, prints message and exits
int get_char(void) {
  const char c = readchar(true);
  if (c == -1) {
    printf("exit: invalid character\n");
    exit(1);
  }
  return c;
}


int main(void) {
  while (1) {
    const char command = readchar(true);
    if (command == -1 || command == 'q') {
      break;
    }
    if (command == 't') {
      const int l = get_nat();
      const int c = get_char();
      triangle(l, c);
    } else if (command == 'b') {
      const int w = get_nat();
      const int h = get_nat();
      const int c = get_char();
      box(w, h, c);
    } else if (command == 'd') {
      const int l = get_nat();
      const int c = get_char();
      diamond(l, c);
    }  else if (command == 'c') {
      const int w = get_nat();
      const int h = get_nat();
      const int s = get_nat();
      const int c1 = get_char();
      const int c2 = get_char();
      checker(w, h, s, c1, c2);
    } else if (command == 's') {
      const int l = get_nat();
      sequence(l);
    } else if (command == 'f') {
      const int l = get_nat();
      const int f = get_nat();
      const int b = get_nat();
      fizz_buzz(l, f, b);
    } else {
      printf("invalid command: %c\n", command);
      return 1;
    }
  }
}

