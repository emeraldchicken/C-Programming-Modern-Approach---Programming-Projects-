
// the following require:
// c1, c2 are between '!' and '~' inclusive
// len, width, height, size are all >= 1
// fizz, buzz are > 1 and different

void checker(int width, int height, int size, char c1, char c2);

void sequence(int len);

void fizz_buzz(int len, int fizz, int buzz);