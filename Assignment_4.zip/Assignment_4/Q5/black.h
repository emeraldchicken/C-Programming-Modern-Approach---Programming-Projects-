
// the following require:
// c is between '!' and '~' inclusive
// len, width, height are all >= 1

void triangle(int len, char c);

void box(int width, int height, char c);

void diamond(int len, char c);

