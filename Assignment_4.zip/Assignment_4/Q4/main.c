#include <stdio.h>
//#include "readchar.h"

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:
  
/*Write a program that reads in an arbitrary number of characters. For each character, if it is a letter (upper or lower case) the equivalent ROT13 character is printed, otherwise the character is printed unchanged.*/


int main(void) {
  char ch;
  
  while (scanf("%c", &ch) == 1) {
    
    if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122)) {
      if (ch > 77 && ch <= 90) {
        ch = (13 - (90 - ch)) + 65;
      } else if (ch > 109) {
        ch = (13 - (122 - ch)) + 97;
      } else {
        ch += 13;
      }
      printf("ROT13: %c\n", ch);
    }
  }
}

