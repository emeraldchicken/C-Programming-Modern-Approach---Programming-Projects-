/**
 * Welcome to Seashell!
 */

#include <stdio.h>

int main(void) {
	// You can enter your code here.
	printf("Hello World!\n");
  int Bob__Sally = 0;
  int _Bob_Sally = 0;
  
  Bob__Sally = 2;
  _Bob_Sally = 2;
  
  printf("%6d,%8.d\n", 86, 1040); // be 
}
