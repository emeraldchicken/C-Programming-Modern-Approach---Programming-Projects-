#include <stdbool.h>
#include <stdio.h>

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:

// readchar(ignore_ws) reads in an ASCII character from input
//   and returns the character or -1 if EOF.
//   if ignore_ws is true then it ignores whitespace (returns the next
//   non-whitespace character).  If false then it returns the next char
char readchar(const bool ignore_ws) {
  char input = -1;
  if (ignore_ws) {
    scanf("%c", &input);
  } else {
    scanf("%c", &input);
  }
  return input;
}

/*int main(void) {
  readchar(true);
  readchar(false);
}*/
