#include <stdio.h>
#include "readnat.h"
#include "readchar.h"

// a very simple test program for readchar & readnat

int main(void) {
  int x = readnat();
  char y = readchar(true);
  char z = readchar(false);
  printf ("(%d,%c,%c)\n", x, y, z);
}
