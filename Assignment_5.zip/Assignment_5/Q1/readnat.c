#include <stdio.h>

// INTEGRITY STATEMENT (modify if necessary)
// I received help from the following sources:
// None. I am the sole author of this work 

// sign this statement by removing the line below and entering your name
//ERROR_I_have_NOT_yet_completed_the_INTEGRITY_statement
// Name:
// login ID:

// readnat() reads in a natural number from input
//   and returns the number or -1 if EOF or invalid input
//   Note: maximum return value is 2147483647
int readnat(void) {
  int input = -1;
  scanf("%d", &input);
  if (input >= 0) {
    return input;
  } 
  return -1;
}
