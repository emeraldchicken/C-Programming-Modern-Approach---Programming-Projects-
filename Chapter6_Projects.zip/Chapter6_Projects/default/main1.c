#include <stdio.h>

// main function
int main(void) {
	printf("%.3lf\n", 9.000); //after dot, decimal places
  printf("%3.lf\n", 9.000); // before dot, spaces
  printf("%.3d\n", 9);
  printf("%3d\n", 9);
  printf("%03d\n", 9);
  //printf("%03d\n", 9);
}