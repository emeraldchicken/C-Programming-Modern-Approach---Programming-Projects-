/**
 * Welcome to Seashell!
 */

#include <stdio.h>

// #2
void gcd(int m, int n) {
  /*int n = 0;
  int m = 0;*/
  //int smaller = 0;
  int gcd = 0;
  int temp = 0;
  
  /*printf("Enter two integers: ");
  scanf("%d", &n);
  scanf("%d", &m);*/
  
  while (n != 0) {
      temp = m % n;
      printf("R: %d\n", temp);
      m = n;
      printf("m: %d\n", m);
      n = temp;
      printf("n: %d\n", n);
  }
  gcd = m;
  printf("The GCD is: %d\n", gcd);
}

// #3
void lowest_terms(void) {
  int first = 0;
  int second = 0;
  
  printf("Enter a fraction: ");
  scanf("%d", first);
  printf("/");
  scanf("%d", second);
  
  int gcd = gcd(first, second);
  
  printf("The fraction in lowest terms is: %d/%d", gcd/first, gcd/second);
}

// 4: broker.c

// 5: Project 1 in Chapter 4

// 6

void even_squares(void) {
  int input = 0;
  scanf("%d", input);
  
  for (int i = 1; i <= input; i++) {
    if (i % 2 == 0 && i % sqrt(i) == 0) {
      printf("i\n");
    }
  }
}

// 8
void() {
  int num_days = 0;
  int day = 0;
  printf("Enter number of days in a month: ");
  scanf("%d", num_days);
  printf("Enter starting day of the week (1 = Sun 7 = Sat):");
  scanf("%d", day);
  
  printf(".%d%c", day, 32); //CHECK HOW TO PUT SPACES
   
  for (int i = 0; i < num_days; i++) {
    if (day == 7) {
      printf("%d\n", i);
    } else {
      printf("%d", i);
      day = 0;  
    }
    day++;
  }
}

// 9: Project 8 in Chap 2

// 10: Project 9 in Chap 5

// 11

int factorial(int n) {
  int factorial = 0;
  for (int i = 1; i <= n; i++) {
    factorial *= i;    
  }
}

void approx_e(void) {
  int n = 0;
  int e = 1;
  scanf("%d", n);
  
  for (int i = 1; i <= n ; i++) {
    e += 1/factorial(i);      
  }
}

void approx_e2(void) {
  int e = 0;
  int term = 1;
  int i = 1;
  scanf("%d", e);
  
  while (term < e) {
    term += 1/factorial(i);  
    i++;
  }
  printf("Current term: %d", term);
}

// main function
int main(void) {
	lowest_terms();
  
}

//DECIMAL PLACES???
