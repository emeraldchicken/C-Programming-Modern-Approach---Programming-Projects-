#include <stdio.h>

void stars(void) {
  char *star = "*";
  printf("%10s\n", star);
  printf("%9s\n", star);
  printf("%8s\n", star);
  printf("%s", star);
  printf("%6s\n", star);
  printf("%1s", star);
  printf("%5s\n", star);
  printf("%2s", star);
  printf("%3s\n", star);
}

int sphere(void) {
  int radius = 0;
  scanf("%d", &radius); 
  double volume = (4.0f/3.0f) * 3.14 * radius * radius * radius;
  printf("%lf\n", volume);
  return volume;
}

int polynomials(void) {
  int x = 0;
  
  scanf("%d", &x);
  
  int poly = ((((3 * x + 2) * x - 5) * x - 1) * x + 7) * x - 6;
  printf("%d\n", poly);
  
  return poly;
}

void dollar(void) {
  int dollar = 0;
  printf("Enter a dollar amount: ");  
  scanf("%d", &dollar);

  printf("$20 Bill: %d\n", dollar / 20);
  dollar = dollar % 20;
  printf("$10 Bill: %d\n", dollar / 10);
  dollar = dollar % 10;
  printf("$5 Bill: %d\n", dollar / 5);
  dollar = dollar % 5;
  printf("$1 Bill: %d\n", dollar);
  
}

void loan(void) {
  double loan, int_rate, month_pay = 0;
  int balance = 0;
  printf("Enter amount of loan: ");   
  scanf("%2.lf", &loan);
  printf("Enter interest rate: ");
  scanf("%.lf", &int_rate);
  printf("Enter monthly payment: ");
  scanf("%2.lf", &month_pay);
  
  int_rate = int_rate / 12;
  
  balance = balance - month_pay + (loan * int_rate);
  
  // DON'T KNOW HOW TO DO ONLY INTEGERS
}

int main(void) {
  //stars();
  //sphere();
  //polynomials();
  dollar();
  loan();
}